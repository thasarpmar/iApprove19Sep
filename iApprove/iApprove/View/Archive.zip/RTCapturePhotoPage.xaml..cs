﻿using ProjectTemplate.Interface;
using ProjectTemplate.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using ProjectTemplate.CustomControl;
using ProjectTemplate.Model;
using System.IO;

namespace ProjectTemplate.View
{
	public partial class RTCapturePhotoPage : BaseContentPage
	{
		private ItemDetailModel navParam = null;
		private RTCapturePhotoViewModel vm;

		public RTCapturePhotoPage()
		{
			InitializeComponent();
			MessageHandler messageHandler = MessageHandler.GetInstance(this);
			IMediaController mediaController = new MediaService(messageHandler);
			vm = new RTCapturePhotoViewModel(App.NavigationServiceInstance,messageHandler,mediaController);
            this.BindingContext = vm;
			Init();
			vm.LoadPhotoList();
		}
		public RTCapturePhotoPage(object args)
		{
			MessageHandler messageHandler = MessageHandler.GetInstance(this);
			IMediaController mediaController = new MediaService(messageHandler);
			vm = new RTCapturePhotoViewModel(App.NavigationServiceInstance, messageHandler, mediaController);
			InitializeComponent();
			this.BindingContext = vm;
			Init();
			vm.LoadPhotoList();
		}

		private void Init()
		{
			vm.PropertyChanged += (object sender, System.ComponentModel.PropertyChangedEventArgs e) =>
			{
				if (e.PropertyName == "PhotoList")
				{
					listPhotos.Children.Clear();
					var photoList = vm.PhotoList;
					foreach (var photo in photoList)
					{
						Image img = new Image()
						{
							HorizontalOptions = LayoutOptions.Start,
							VerticalOptions = LayoutOptions.Center,
							WidthRequest = 50,
							HeightRequest = 50,
							Source = ImageSource.FromFile(photo),
							Margin = new Thickness(5, 0, 5, 0)
						};
						listPhotos.Children.Add(img);
					}
				}
			};
		}
	}
}
